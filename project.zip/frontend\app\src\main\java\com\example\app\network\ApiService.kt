package com.example.app.network

import com.example.app.network.models.*
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {
    @POST("api/auth/register")
    suspend fun register(@Body request: RegisterRequest):
    Response<AuthResponse>

    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest):
    Response<AuthResponse>

    @GET("api/user/profile")
    suspend fun getProfile():
    Response<UserProfileResponse>

    @POST("api/auth/send-otp")
    suspend fun sendOtp(@Body request: SendOtpRequest): Response<AuthResponse>

    @POST("api/auth/verify-otp")
    suspend fun verifyOtp(@Body request: VerifyOtpRequest): Response<AuthResponse>

    @GET("api/dashboard")
    suspend fun getDashboard():
    Response<DashboardResponse>
}